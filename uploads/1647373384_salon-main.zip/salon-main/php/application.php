<?php
require_once("connection.php");

$name = $_POST['name'];
$tel = $_POST['tel'];
$email = $_POST['email'];

$error_fields = [];

if($name === ''){
    $error_fields[] = 'name';
}

if($tel === ''){
    $error_fields[] = 'tel';
}

if($email==='' || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    $error_fields[] = 'email';
}

if(!empty($error_fields)){
    $response = [
        "status" => false,
        "type" => 1,
        "messenge" => "Проверьте правельность полей",
        "fields" => $error_fields
    ];

    echo json_encode($response);

    die();
}

$application =  mysqli_query($connect,"INSERT INTO `customer` (`id`, `name`, `tel`, `email`) VALUES (NULL, '$name', '$tel', '$email')");

$response = [
    "status" => true
];

echo json_encode($response);

$connect->close();