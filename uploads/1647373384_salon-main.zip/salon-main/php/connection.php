<?php
$connect = mysqli_connect("localhost", "root","", "salon") or die (" Ошибка при подключении ". mysqli_error($conn));
?>