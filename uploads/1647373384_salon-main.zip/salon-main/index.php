<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/view.css">
  <link rel="stylesheet" href="css/adaptive.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&family=Neonderthaw&display=swap" rel="stylesheet">
  <title>salon</title>
</head>
<body>

<?php require_once("header.php");?>

    <button class="btn-record open-pop-up">
      <div class="btn-text" id="open-pop-up">Онлайн запись</div>
    </button>
    <div class="pop_up" id = "pop_up">
      <div class="pop_up_container">
        <div class="pop_up_body" id = "pop_up_body">
          <p>Оставить заказ</p>
          <form>
            <label for="" class="label">Имя</label>
            <input type="text" name = "name" class="input" placeholder="Имя">
            <label for="" class="label">Телефон</label>
            <input type="text" name = "tel" id="phone" class="input" placeholder="Телефон" value="">
            <label for="" class="label">E-mail</label>
            <input type="text" name = "email" class="input" placeholder="E-mail">
            <p class="msg none">qwe</p>
            <button class="btn btn-send">Записаться</button>
          </form>
          <div class="pop_up_close" id="pop_up_close">&#10006</div>
        </div>
      </div>
    </div>

  


<main>
  <div class="container-wide">
    <div class="row">
      <div class="content-start row">
        <div class="content-title">Добро <br> Пожаловать</div>
        <div class="content-text">Современное оборудование и профессионализм персонала позволяют удовлетворить требования самых взыскательных клиентов, как мужчин, так и женщин. Для самых маленьких наших клиентов действует постоянная скидка на стрижки.
<br><br>
          Парикмахерские залы, залы для маникюра и педикюра, кабинеты косметологии для лица и тела — к вашим услугам!
        </div>
     
        </div>
    </div>    
      <div class="service">
        <div class="content-title">Услуги</div>  
        <div class="service-name">Стрижка</div> 
        <img src="img/pictures/strigka.jpg" alt="" class="service-img">
        <div class="service-name">Окрашивание</div> 
        <img src="img/pictures/okrashiv.jpg" alt="" class="service-img">
        <div class="service-name">Укладка</div> 
        <img src="img/pictures/ykladka.jpg" alt="" class="service-img">
        <div class="service-name">Создание причесок</div> 
        <img src="img/pictures/sozPrech.jpg" alt="" class="service-img">
      </div>
  </div>
</main>
<main class="fast-record">
  <div class="container-wide">
    <div class="content-title">Быстрая запись на<br> консультации и процедуры</div>
    <div class="content-text">Наши операторы проведут первичную консультацию<br> по услугам и запишут вас к специалистам:</div>
    
    <div class="connect">
      <div class="row center">
        <a href="tel:+79999999999"><button class="btn">+7 (999) 999-99-99</button></a>
      </div>
      
    </div>
  </div>
</main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/maskedinput/jquery.maskedinput.js"></script>
</body>
</html>     