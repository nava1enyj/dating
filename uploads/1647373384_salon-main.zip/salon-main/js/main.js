
/* popup */


$('.open-pop-up').click(function(e){
  e.preventDefault();
  $('.pop_up').fadeIn(600);
  $('html').addClass('no__scroll');
});

$('.pop_up_close').click(function(){
  $('.pop_up').fadeOut(600);
  $('html').removeClass('no__scroll');
});

jQuery(function($){
  $("#phone").mask("+7 (999) 999-9999");
});

/* check */
$('.btn-send').click(function (e){
  $(`input`).removeClass('error');
  e.preventDefault();
  let name = $('input[name = "name"]').val(),
  tel = $('input[name = "tel"]').val(),
  email = $('input[name = "email"]').val();

  $.ajax({
    url: 'php/application.php',
    type: 'POST',
    dataType: 'json',
    data: {
      name: name,
      tel: tel,
      email: email
    },
    success (data){

      if(data.status){
        $('.msg').removeClass('none').text('Вы успешно оставили заявку');
        $('.msg').addClass('green-msg');
      }
      else{
        if(data.type === 1){
          data.fields.forEach(function (field){
            $(`input[name= "${field}"]`).addClass('error');
          });
        }
        $('.msg').removeClass('none').text(data.messenge);
        $('.msg').addClass('red-msg');

      }

    }
  });

});
